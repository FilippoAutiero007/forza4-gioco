﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forza4FilippoAutiero
{
    public partial class FrmForza4 : Form
    {
        //Constanti 
        const int DIMENSIONI_CELLA = 50;


        private string giocatore1;
        private string giocatore2;


        public FrmForza4(string nomeGiocatore1, string nomeGiocatore2)
        {
            InitializeComponent();
            giocatore1 = nomeGiocatore1;
            giocatore2 = nomeGiocatore2;
            btGioca.Enabled = false; 
        }

        private void btAccedi_Click(object sender, EventArgs e)
        {
            FrmRegistrazione frmRegistrazione = new FrmRegistrazione();
            if (frmRegistrazione.ShowDialog() == DialogResult.OK)
            {
                giocatore1 = frmRegistrazione.NomeGiocatore1;
                giocatore2 = frmRegistrazione.NomeGiocatore2;
                btGioca.Enabled = true; // Abilita il pulsante di gioco
            }
            else
            {
                MessageBox.Show("Assicurati che entrambi i giocatori siano registrati.", "Errore");
                btGioca.Enabled = false;
            }
        }

        private void btGioca_Click(object sender, EventArgs e)
        {

            if (nudX.Value >= 4 && nudY.Value >= 4)
            {
                int x = (int)nudX.Value;
                int y = (int)nudY.Value;
                FrmGioca frmGioca = new FrmGioca(x, y, DIMENSIONI_CELLA, giocatore1, giocatore2);
                frmGioca.ShowDialog();
                if (!string.IsNullOrWhiteSpace(giocatore1) && !string.IsNullOrWhiteSpace(giocatore2))
                {

                    btGioca.Enabled = true;
                }
                else
                {
                    btGioca.Enabled = false;

                    MessageBox.Show("Assicurati che entrambi i giocatori siano registrati.", "Errore");
                }

            }
            else
            {
                MessageBox.Show("Inserisci le dimensioni con cui vuoi giocare la dimensione minima e 4X4","ERRORE");
            }

        }

    }
}
