﻿namespace Forza4FilippoAutiero
{
    partial class FrmForza4
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.btAccedi = new System.Windows.Forms.Button();
            this.btGioca = new System.Windows.Forms.Button();
            this.nudY = new System.Windows.Forms.NumericUpDown();
            this.nudX = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nudY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudX)).BeginInit();
            this.SuspendLayout();
            // 
            // btAccedi
            // 
            this.btAccedi.Location = new System.Drawing.Point(550, 37);
            this.btAccedi.Name = "btAccedi";
            this.btAccedi.Size = new System.Drawing.Size(111, 46);
            this.btAccedi.TabIndex = 0;
            this.btAccedi.Text = "ACCEDI";
            this.btAccedi.UseVisualStyleBackColor = true;
            this.btAccedi.Click += new System.EventHandler(this.btAccedi_Click);
            // 
            // btGioca
            // 
            this.btGioca.Location = new System.Drawing.Point(168, 199);
            this.btGioca.Name = "btGioca";
            this.btGioca.Size = new System.Drawing.Size(240, 84);
            this.btGioca.TabIndex = 1;
            this.btGioca.Text = "GIOCA";
            this.btGioca.UseVisualStyleBackColor = true;
            this.btGioca.Click += new System.EventHandler(this.btGioca_Click);
            // 
            // nudY
            // 
            this.nudY.Location = new System.Drawing.Point(52, 437);
            this.nudY.MaximumSize = new System.Drawing.Size(120, 0);
            this.nudY.Minimum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.nudY.MinimumSize = new System.Drawing.Size(120, 0);
            this.nudY.Name = "nudY";
            this.nudY.Size = new System.Drawing.Size(120, 20);
            this.nudY.TabIndex = 2;
            this.nudY.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // nudX
            // 
            this.nudX.Location = new System.Drawing.Point(49, 365);
            this.nudX.Minimum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.nudX.Name = "nudX";
            this.nudX.Size = new System.Drawing.Size(120, 20);
            this.nudX.TabIndex = 3;
            this.nudX.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(21, 411);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(245, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "NUMERO CASELLE VERTICALI";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(21, 339);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(257, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "NUMERO CASELLE ORIZONTALI";
            // 
            // FrmForza4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Forza4FilippoAutiero.Properties.Resources.frmForza4;
            this.ClientSize = new System.Drawing.Size(691, 499);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.nudX);
            this.Controls.Add(this.nudY);
            this.Controls.Add(this.btGioca);
            this.Controls.Add(this.btAccedi);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximumSize = new System.Drawing.Size(707, 538);
            this.MinimumSize = new System.Drawing.Size(707, 538);
            this.Name = "FrmForza4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nudY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudX)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btAccedi;
        private System.Windows.Forms.Button btGioca;
        private System.Windows.Forms.NumericUpDown nudY;
        private System.Windows.Forms.NumericUpDown nudX;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

