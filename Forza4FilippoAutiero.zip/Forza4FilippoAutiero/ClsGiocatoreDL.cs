﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
namespace Forza4FilippoAutiero
{
    class ClsGiocatoreDL
    {
        //Construttore
        public ClsGiocatoreDL(string Nome, bool ColorePedineRosso, int NumeroPartiteVinte)
        {
            this.Nome = Nome;
            this.ColorePedineRosso = ColorePedineRosso;
            this.NumeroPartiteVinte = NumeroPartiteVinte;
        }

        #region VARIABILI
        string _nome;
        bool _colorePedineRosso;
        int _numeroPartiteVinte;
        #endregion

        #region PROPRIETA
        public string Nome
        {
            get
            {
                return _nome;
            }
            set
            {
                if (!string.IsNullOrWhiteSpace(value))
                    _nome = value;
                else
                    throw new Exception("Il nome non può essere vuoto");
            }
        }
        public bool ColorePedineRosso { get => _colorePedineRosso; set => _colorePedineRosso = value; }
        public int NumeroPartiteVinte { get => _numeroPartiteVinte; set => _numeroPartiteVinte = value; }
        #endregion

    }
}
