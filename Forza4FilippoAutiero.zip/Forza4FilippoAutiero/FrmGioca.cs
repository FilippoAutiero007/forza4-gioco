﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forza4FilippoAutiero
{
    public partial class FrmGioca : Form
    {
        //Variabili utili per spostrare le PictureBox nella Form
        Point PosizioneIniziale;
        bool PbPremuta;

        bool TurnoDelRosso;

        private ClsGrigliaDL GrigliaDiGioco;
        ClsGiocatoreDL Giocatore1;
        ClsGiocatoreDL Giocatore2;
        Point PosizionePrimaCasella;
        private List<Panel> ListaPannelli = new List<Panel>();

        //costanti
        const int POSIZIONE_INIZIALE_X = 20;    // Posizione iniziale X
        const int POSIZIONE_INIZIALE_Y = 80;    // Posizione iniziale Y

        //Chiedo in input le dimesioni della griglia di gioco (altezza e larghezza) oltre che i nomi dei giocatori
        public FrmGioca(int x, int y, int DimesioniCella, string NomeGiocatore1, string NomeGiocatore2)
        {
            InitializeComponent();
            GrigliaDiGioco = new ClsGrigliaDL(x, y);
            Giocatore1 = new ClsGiocatoreDL(NomeGiocatore1, true, 0);
            Giocatore2 = new ClsGiocatoreDL(NomeGiocatore2, false, 0);
            PosizionePrimaCasella = GeneraGriglia(x, y, DimesioniCella, POSIZIONE_INIZIALE_X, POSIZIONE_INIZIALE_Y);
            GeneraMuchi(DimesioniCella, PosizionePrimaCasella);
            GeneraPannelli(DimesioniCella, POSIZIONE_INIZIALE_X, POSIZIONE_INIZIALE_Y, x);
            TurnoDelRosso = true;
        }

        private void GeneraPannelli(int dimesioniCella, int PosizioneInizialeX, int PosizioneInizialeY, int colonne)
        {
            for (int NumColonne = colonne - 1; NumColonne >= 0; NumColonne--)
            {
                Panel panel = new Panel
                {
                    Name = "Pannello" + NumColonne,
                    Size = new Size(dimesioniCella, dimesioniCella),
                    //BackColor = Color.Blue,
                    Location = new Point(PosizioneInizialeX + (colonne - NumColonne - 1) * dimesioniCella, PosizioneInizialeY - dimesioniCella)
                };
                ListaPannelli.Add(panel);
                this.Controls.Add(panel);
            }
        }

        private void FrmGioca_Load(object sender, EventArgs e)
        {

        }

        // Metodo per generare la griglia
        public Point GeneraGriglia(int DimensioneX, int DimensioneY, int DimesioniCella, int PosizioneInizialeX, int PosizioneInizialeY)
        {
            Point PosizionePrimaCasella = new Point(PosizioneInizialeX + (DimensioneX - 1) * DimesioniCella, PosizioneInizialeY + (DimensioneY - 1) * DimesioniCella);


            for (int _righe = DimensioneY - 1; _righe >= 0; _righe--) // Ciclo righe
            {
                for (int _colonne = DimensioneX - 1; _colonne >= 0; _colonne--) // Ciclo colonne
                {
                    PictureBox pb = new PictureBox
                    {
                        Name = "Casella" + _colonne + "-" + _righe,
                        Size = new Size(DimesioniCella, DimesioniCella),  //  50x50 pixel
                        Location = new Point(PosizioneInizialeX + (DimensioneX - _colonne - 1) * DimesioniCella, PosizioneInizialeY + (DimensioneY - _righe - 1) * DimesioniCella), // Posizione calcolata
                        SizeMode = PictureBoxSizeMode.StretchImage  // Adatta immagine
                    };

                    // Carico l'immagine casella.png
                    pb.Image = Image.FromFile("casella.png");
                    this.Controls.Add(pb);
                }
            }

            // la dimensione della form in base alla griglia
            this.ClientSize = new Size(DimensioneX * DimesioniCella + 250, DimensioneY * DimesioniCella + 120);
            return PosizionePrimaCasella;
        }

        public void GeneraMuchi(int DimensioniCella, Point PuntoRiferimeto)
        {
            // Posizione iniziale delle pedine, 50px a destra dall'ultima cella della griglia
            int _posizioneInizialeX = PuntoRiferimeto.X + DimensioniCella + 30;
            int _posizioneInizialeY = PuntoRiferimeto.Y;

            // Genera le pedine rosse (mucchio giallo)
            for (int i = 0; i < 2; i++)
                GeneraPedina(_posizioneInizialeX, _posizioneInizialeY, DimensioniCella, true);

            // Genera le pedine gialle (mucchio rosso)
            for (int i = 0; i < 2; i++)
                GeneraPedina(_posizioneInizialeX + DimensioniCella + 20, _posizioneInizialeY, DimensioniCella, false);
        }

        private void GeneraPedina(int PosizioneX, int PosizioneY, int DimesioniCella, bool ColoreRosso)
        {
            PictureBox pb = new PictureBox
            {
                Location = new Point(PosizioneX, PosizioneY),
                Size = new Size(DimesioniCella, DimesioniCella),
                SizeMode = PictureBoxSizeMode.StretchImage,
                Name = ColoreRosso ? "PedinaRossa" : "PedinaGialla"

            };
            if (ColoreRosso)
                pb.Image = Image.FromFile("PedinaRossa.png");
            else
                pb.Image = Image.FromFile("PedinaGialla.png");
            pb.MouseDown += PremiPb;
            pb.MouseUp += RilasciaPb;
            pb.MouseMove += MovimentoPb;
            this.Controls.Add(pb);
        }

        private void MovimentoPb(object sender, MouseEventArgs e)
        {
            PictureBox PbDaMuovere = (PictureBox)sender;
            if (PbPremuta)
            {
                Point PosizioneMouse = PointToClient(MousePosition); //Il punto contiene la posizione del Mouse
                Point PoiszioneVariabile = MousePosition;
                PosizioneMouse.Offset(-PosizioneIniziale.X, -PosizioneIniziale.Y);
                PbDaMuovere.Location = PosizioneMouse;
                //Controllo se la pb (o meglio il mouse) è sopra un pannello, altrimenti sara null
            }

        }

        private void PremiPb(object sender, MouseEventArgs e)
        {
            PictureBox PbDaMuovere = (PictureBox)sender;
            bool ColorePedinaRosso = PbDaMuovere.Name.Contains("Rossa");
            if (TurnoDelRosso == ColorePedinaRosso)
                PbPremuta = true;
            PosizioneIniziale = e.Location; //Memorizzo la posizione del Mouse
            PbDaMuovere.BringToFront();

        }

        private void RilasciaPb(object sender, MouseEventArgs e)
        {
            PbPremuta = false;
            PictureBox PbDaMuovere = (PictureBox)sender;
            Point PosizioneMouse = Control.MousePosition;
            //Qui va un controllo che verifica se la Pb è stata rilascita su un Pannel (che ancora non esiste)
            Panel PannelloSottoIlMouse = TrovaPannelloSottoIlMouse(PosizioneMouse);
            ePosizionepedinaRisultato pdr;

            if (PannelloSottoIlMouse != null)
            {
                //Il mouse è stato rilasciato su un pannello
                PbDaMuovere.Parent.Controls.Remove(PbDaMuovere);  //Così la Pb scompare dallo schermo
                int Colonna = Convert.ToInt32(PannelloSottoIlMouse.Name.Remove(0, 8));
                bool ColorePedinaInseritaRosso = RigeneraPictureBox(PbDaMuovere);
                ClsPedina PedinaInserita;

                pdr = ColorePedinaInseritaRosso ? ClsGiocatoreBL.InserisciPedinaInColonna(GrigliaDiGioco, Colonna, Giocatore1, out PedinaInserita) : ClsGiocatoreBL.InserisciPedinaInColonna(GrigliaDiGioco, Colonna, Giocatore2, out PedinaInserita);

                if (pdr == ePosizionepedinaRisultato.Posizionata)
                {
                    CambiaImmagineCasella(PedinaInserita.PosizioneX, PedinaInserita.PosizioneY, ColorePedinaInseritaRosso);
                }
                else if (pdr == ePosizionepedinaRisultato.Vittoria)
                {
                    CambiaImmagineCasella(PedinaInserita.PosizioneX, PedinaInserita.PosizioneY, ColorePedinaInseritaRosso);
                    string NomeVincitore = ColorePedinaInseritaRosso ? Giocatore1.Nome : Giocatore2.Nome;
                    MessageBox.Show(NomeVincitore + " ha vinto !!!");
                    this.Close();
                }
                else if (pdr == ePosizionepedinaRisultato.ColonnaPiena)
                    MessageBox.Show("La colonna è piena");

            }

        }
        internal void CambiaImmagineCasella(int colonna, int riga, bool ColorePedinaRosso)
        {
            string NomePictureBox = string.Concat("Casella", colonna, "-", riga);
            PictureBox CasellaDaCambiare = (PictureBox)this.Controls[NomePictureBox];
            CasellaDaCambiare.Image = ColorePedinaRosso ? Image.FromFile("casellaRossa.png") : Image.FromFile("casellaGialla.png");
        }

        private bool RigeneraPictureBox(PictureBox PbDaMuovere)
        {
            int _posizioneInizialeX = PosizionePrimaCasella.X + 80;
            int _posizioneInizialeY = PosizionePrimaCasella.Y;
            bool ColorePedinaRosso = PbDaMuovere.Name.Contains("Rossa");
            if (ColorePedinaRosso)
                GeneraPedina(_posizioneInizialeX, _posizioneInizialeY, 50, true);
            else
                GeneraPedina(_posizioneInizialeX + 70, _posizioneInizialeY, 50, false);
            return ColorePedinaRosso;
        }

        private Panel TrovaPannelloSottoIlMouse(Point PosizioneMouse)
        {
            Panel PannelloSottoIlMouse = null;
            foreach (Panel pannello in ListaPannelli)
            {
                if (pannello.RectangleToScreen(pannello.ClientRectangle).Contains(PosizioneMouse))
                {
                    PannelloSottoIlMouse = pannello;
                    break;
                }
            }

            return PannelloSottoIlMouse;
        }
    }
}
