﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;// per le pb
using System.Drawing;//per le immagini 
namespace Forza4FilippoAutiero
{
    class ClsPedina
    {
        bool _coloreRosso;
        bool _inGioco;
        int _posizioneX;
        int _posizioneY;
        PictureBox pb;
        #region PROPRIETA
        public bool ColoreRosso
        {
            get
            {
                return _coloreRosso;
            }
            set
            {
                _coloreRosso = value;
            }
        }
        public int PosizioneX
        {
            get
            {
                return _posizioneX;
            }
            set
            {
                _posizioneX = value;
            }
        }

        public int PosizioneY
        {
            get
            {
                return _posizioneY;
            }
            set
            {
                _posizioneY = value;
            }
        }

        public bool InGioco
        {
            get
            {
                return _inGioco;
            }
            set
            {
                _inGioco = value;
            }
        }

        public PictureBox Pb { get => pb; set => pb = value; }
        #endregion



        public ClsPedina(bool ColoreRosso, int PosizioneX, int PosizioneY, bool InGioco)
        {
            this.ColoreRosso = ColoreRosso;
            this.PosizioneX = PosizioneX;
            this.PosizioneY = PosizioneY;
            this.InGioco = InGioco;
        }

    }
}
