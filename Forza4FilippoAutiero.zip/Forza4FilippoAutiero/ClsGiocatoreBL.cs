﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Forza4FilippoAutiero
{
    static class ClsGiocatoreBL
    {
        #region METODI
        static public ePosizionepedinaRisultato InserisciPedinaInColonna(ClsGrigliaDL grigliaDiGioco, int Colonna, ClsGiocatoreDL clsGiocatoreDL, out ClsPedina PedinaInserita)
        {
            PedinaInserita = null;
            //Ho la coordinata X ma mi serve anche la Y, che sarebbe l'ultima posizione disponibile nella colonna che già ho
            int Riga = ClsGrigliaBL.TrovaUltimoSpazioVuoto(Colonna, grigliaDiGioco); //Trovo la posizione più bassa della colonna
            if (Riga != -1) //Se la funzione ha restituito -1 significa che la colonna selezionata era piena
            {
                grigliaDiGioco.GrigliaPedine[Colonna, Riga] = new ClsPedina(clsGiocatoreDL.ColorePedineRosso, Colonna, Riga, true);
                grigliaDiGioco.GrigliaPedine[Colonna, Riga] = PedinaInserita;
                if (ClsGrigliaBL.ControlloVittoria(Colonna, Riga, grigliaDiGioco))
                    return  ePosizionepedinaRisultato.Vittoria;
                else
                    return ePosizionepedinaRisultato.Posizionata;

            }
            else
                return ePosizionepedinaRisultato.ColonnaPiena;
        }


        #endregion
    }
}
