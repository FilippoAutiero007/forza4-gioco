﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forza4FilippoAutiero
{
    public partial class FrmRegistrazione : Form
    {
        public FrmRegistrazione()
        {
            InitializeComponent();
        }
        public string NomeGiocatore1  = string.Empty;
        public string NomeGiocatore2 = string.Empty;
        private void btConferma_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(tbNik1.Text) && !string.IsNullOrWhiteSpace(tbNik2.Text))
            {
                NomeGiocatore1 = tbNik1.Text;
                NomeGiocatore2 = tbNik2.Text;
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show("inserisci i campi richiesti", "errore");
            }
            
        }
    }
}
