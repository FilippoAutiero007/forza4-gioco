﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forza4FilippoAutiero
{
    static class Program
    {
        /// <summary>
        /// Punto di ingresso principale dell'applicazione.
        /// </summary>
        [STAThread]
        static void Main()
        {
            string nomeGiocatore1 = "Giocatore 1";
            string nomeGiocatore2 = "Giocatore 2"; 

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FrmForza4(nomeGiocatore1, nomeGiocatore2));

        }
    }

    //Strutture dati
    public enum eTraiettorie
    {
        Alto = 1,
        AltoDestra,
        Destra,
        BassoDestra,
        Basso,
        BassoSinistra,
        Sinistra,
        AltoSinistra
    }
    public enum ePosizionepedinaRisultato
    {
        Posizionata,
        Vittoria,
        ColonnaPiena
    }

}
