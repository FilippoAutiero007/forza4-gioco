﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;
namespace Forza4FilippoAutiero
{
    static class ClsGrigliaBL
    {
        #region METODI


        static internal int TrovaUltimoSpazioVuoto(int colonna, ClsGrigliaDL grigliaDiGioco)
        {
            for (int i = 0; i < grigliaDiGioco.DimensioneY; i++)
            {
                if (grigliaDiGioco.GrigliaPedine[colonna, i] == null)
                    return i;
            }
            return -1;
        }


        //In input chiedo la posizione dell'ultima pedina piazzta, la mossia vincente può apparire solo da lì
        internal static bool ControlloVittoria(int Coordinata_X, int Coordinata_Y,  ClsGrigliaDL grigliaDiGioco)
        {
            bool coloreAlleato = grigliaDiGioco.GrigliaPedine[Coordinata_X, Coordinata_Y].ColoreRosso;

            //controllo per 4 pedine allineate orizzontalmente verticalmente e diagonalmente
            if (ControlloTraiettorie(Coordinata_X, Coordinata_Y, coloreAlleato, grigliaDiGioco))
                return true;
            else
                return false;
        }

        #region Funzioni_Controllo_Traietorie
        private static bool ControlloTraiettorie(int ColonnaDaControllare, int RigaDaControllare, bool ColoreAlleato, ClsGrigliaDL grigliaDiGioco)
        {
            int ColonnaPuntatrice = ColonnaDaControllare;
            int RigaPuntatrince = RigaDaControllare;
            int _sommaRigaArray;
            int _sommaColonnaArray;
            int AlleatiDiFila = 0;
            eTraiettorie traiettoria = eTraiettorie.Alto;
            do
            {
                ColonnaPuntatrice = ColonnaDaControllare;
                RigaPuntatrince = RigaDaControllare;
                CambioCombinazioniSomme(out _sommaRigaArray, out _sommaColonnaArray, ref traiettoria);
                AlleatiDiFila = 1;
                for (int i = 0; i < 3; i++)
                {
                    ColonnaPuntatrice += _sommaColonnaArray;
                    RigaPuntatrince += _sommaRigaArray;
                    if (ColonnaPuntatrice < grigliaDiGioco.DimensioneX  &&
                         RigaPuntatrince < grigliaDiGioco.DimensioneY &&
                         ColonnaPuntatrice >= 0 &&
                         RigaPuntatrince >= 0 &&
                         grigliaDiGioco.GrigliaPedine[ColonnaPuntatrice, RigaPuntatrince] != null)
                    {
                        if (grigliaDiGioco.GrigliaPedine[ColonnaPuntatrice, RigaPuntatrince].ColoreRosso == ColoreAlleato)
                        {
                            AlleatiDiFila++;
                            if (AlleatiDiFila >= 4)
                                return true;
                        }

                        else
                            break;
                    }
                    else
                        break;
                }
            } while (traiettoria != eTraiettorie.Alto);
            return false;
        }

        private static void CambioCombinazioniSomme(out int sommaRigaArray, out int sommaColonnaArray, ref eTraiettorie traiettoria)
        {
            sommaRigaArray = 0;
            sommaColonnaArray = 0;
            switch (traiettoria)
            {
                case eTraiettorie.Alto:
                    sommaRigaArray = 1;
                    break;
                case eTraiettorie.Destra:
                    sommaColonnaArray = 1;
                    break;
                case eTraiettorie.Basso:
                    sommaRigaArray = -1;
                    break;
                case eTraiettorie.Sinistra:
                    sommaColonnaArray = -1;
                    break;
                case eTraiettorie.AltoDestra:
                    sommaRigaArray = 1;
                    sommaColonnaArray = 1;
                    break;
                case eTraiettorie.BassoDestra:
                    sommaRigaArray = -1;
                    sommaColonnaArray = 1;
                    break;
                case eTraiettorie.BassoSinistra:
                    sommaRigaArray = -1;
                    sommaColonnaArray = -1;
                    break;
                case eTraiettorie.AltoSinistra:
                    sommaRigaArray = 1;
                    sommaColonnaArray = -1;
                    break;
            }
            traiettoria++;
            if ((int)traiettoria == 9)
                traiettoria = eTraiettorie.Alto;
        }
        #endregion
    }
    #endregion
}
