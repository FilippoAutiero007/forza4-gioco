﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;// per le pb
using System.Drawing;//per le immagini 
namespace Forza4FilippoAutiero
{
    class ClsGrigliaDL
    {
        public ClsGrigliaDL(int dimensioneX, int dimensioneY)
        {
            DimensioneX = dimensioneX;
            DimensioneY = dimensioneY;
            GrigliaPedine = new ClsPedina[dimensioneX, dimensioneY];
        }

        int _dimensioneX;
        int _dimensioneY;
        ClsPedina[,] _grigliaPedine;

        #region proprieta 
        public int DimensioneX
        {
            get
            {
                return _dimensioneX;
            }
            set
            {
                if (value >= 4)  
                    _dimensioneX = value;
                else
                    throw new Exception("Inserisci un valore valido per DimensioneX!");
            }
        }
        public int DimensioneY
        {
            get
            {
                return _dimensioneY;
            }
            set
            {
                if (value >= 4) 
                    _dimensioneY = value;
                else
                    throw new Exception("Inserisci un valore valido per DimensioneY!");
            }
        }

        public ClsPedina[,] GrigliaPedine { get => _grigliaPedine; set => _grigliaPedine = value; }

        #endregion
    }
}
    
